use std::env;
use std::process::{Command, Stdio};
use std::sync::Arc;
use tauri::{AppHandle, Emitter, Manager, WindowEvent};
use tauri_plugin_log::{Builder as LogBuilder, Target, TargetKind};
use tokio::sync::Mutex;

struct BackendProcess {
    child: Option<std::process::Child>,
}

impl BackendProcess {
    fn new() -> Self {
        Self { child: None }
    }

    fn start(&mut self, app_handle: &AppHandle) -> Result<(), String> {
        let python = Self::find_python().ok_or("Python interpreter not found")?;
        let backend_dir = Self::find_backend_dir().ok_or("PrimeAgent backend directory not found")?;

        let mut child = Command::new(&python)
            .arg("-m")
            .arg("primeagent")
            .arg("run")
            .arg("--host")
            .arg("127.0.0.1")
            .arg("--port")
            .arg("7860")
            .current_dir(&backend_dir)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("Failed to start PrimeAgent backend: {}", e))?;

        let app_handle_clone = app_handle.clone();
        tauri::async_runtime::spawn(async move {
            if let Some(mut stdout) = child.stdout.take() {
                use tokio::io::AsyncBufReadExt;
                let reader = tokio::io::BufReader::new(stdout);
                let mut lines = reader.lines();
                while let Ok(Some(line)) = lines.next_line().await {
                    app_handle_clone.emit("primeagent-backend-log", line).ok();
                }
            }
        });

        tauri::async_runtime::spawn(async move {
            if let Some(mut stderr) = child.stderr.take() {
                use tokio::io::AsyncBufReadExt;
                let reader = tokio::io::BufReader::new(stderr);
                let mut lines = reader.lines();
                while let Ok(Some(line)) = lines.next_line().await {
                    app_handle_clone.emit("primeagent-backend-log", line).ok();
                }
            }
        });

        self.child = Some(child);
        Ok(())
    }

    fn stop(&mut self) {
        if let Some(mut child) = self.child.take() {
            let _ = child.start_kill();
            let _ = child.wait();
        }
    }

    fn find_python() -> Option<String> {
        // Check for uv first (PrimeAgent's preferred package manager)
        if let Ok(path) = which::which("uv") {
            return Some(path.to_string_lossy().to_string());
        }
        // Fall back to python3 / python
        for exe in ["python3", "python"] {
            if let Ok(path) = which::which(exe) {
                return Some(path.to_string_lossy().to_string());
            }
        }
        None
    }

    fn find_backend_dir() -> Option<String> {
        // Look for the PrimeAgent backend relative to the executable
        let exe_dir = env::current_exe().ok()?;
        let exe_parent = exe_dir.parent()?;

        // Common locations for the backend package
        let candidates = [
            exe_parent.join("backend").join("base").join("primeagent"),
            exe_parent.join("src").join("backend").join("base").join("primeagent"),
            exe_parent.parent()?.join("src").join("backend").join("base").join("primeagent"),
            exe_parent.parent()?.parent()?.join("src").join("backend").join("base").join("primeagent"),
        ];

        for candidate in candidates {
            if candidate.join("__main__.py").exists() || candidate.join("main.py").exists() {
                return Some(candidate.to_string_lossy().to_string());
            }
        }

        // Check environment variable
        if let Ok(backend_dir) = env::var("PRIMEAGENT_BACKEND_DIR") {
            if std::path::Path::new(&backend_dir).exists() {
                return Some(backend_dir);
            }
        }

        None
    }
}

impl Drop for BackendProcess {
    fn drop(&mut self) {
        self.stop();
    }
}

#[derive(Default)]
struct AppState {
    backend: Mutex<BackendProcess>,
}

#[tauri::command]
async fn start_backend(state: tauri::State<'_, AppState>, app: AppHandle) -> Result<(), String> {
    let mut backend = state.backend.lock().await;
    backend.start(&app)
}

#[tauri::command]
async fn stop_backend(state: tauri::State<'_, AppState>) -> Result<(), String> {
    let mut backend = state.backend.lock().await;
    backend.stop();
    Ok(())
}

#[tauri::command]
fn backend_status(state: tauri::State<'_, AppState>) -> bool {
    state.backend.try_lock().map(|b| b.child.is_some()).unwrap_or(false)
}

fn main() {
    tauri::Builder::default()
        .plugin(
            LogBuilder::new()
                .targets([
                    Target::new(TargetKind::Stdout),
                    Target::new(TargetKind::LogDir {
                        file_name: None,
                    }),
                ])
                .build(),
        )
        .manage(AppState::default())
        .invoke_handler(tauri::generate_handler![
            start_backend,
            stop_backend,
            backend_status
        ])
        .setup(|app| {
            let app_handle = app.app_handle().clone();

            // Start the PrimeAgent backend automatically on app launch
            let state = app.state::<AppState>();
            let _ = tauri::async_runtime::block_on(start_backend(state, app_handle.clone()));

            // Window event handling for cleanup
            let window = app.get_window("main").unwrap();
            let app_handle_clone = app_handle.clone();
            window.on_window_event(move |event| {
                if matches!(event, WindowEvent::Destroyed) {
                    let state = app_handle_clone.state::<AppState>();
                    tauri::async_runtime::block_on(async {
                        state.backend.lock().await.stop();
                    });
                }
            });

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
