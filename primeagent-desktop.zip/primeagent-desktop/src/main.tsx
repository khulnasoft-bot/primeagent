import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased">
      <header className="border-b border-slate-200 bg-white sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold">PA</div>
            <h1 className="text-xl font-semibold tracking-tight text-slate-900">PrimeAgent<span className="text-indigo-600">Desktop</span></h1>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Backend: localhost:7860
            </span>
          </div>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-6 py-8">
        <section className="space-y-6">
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900 mb-2">Welcome to PrimeAgent Desktop</h2>
            <p className="text-slate-600">
              PrimeAgent Desktop wraps the PrimeAgent AI agent platform in a Tauri window. The backend runs locally on
              <code className="font-mono text-sm">http://localhost:7860</code>.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-3">Open Web UI</h3>
              <p className="text-sm text-slate-600 mb-4">Launch the PrimeAgent visual builder in your system browser.</p>
              <button
                className="inline-flex items-center gap-2 rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 transition"
                onClick={() => {
                  if (typeof window !== 'undefined' && (window as any).__TAURI__) {
                    (window as any).__TAURI__.shell.open('http://localhost:7860');
                  } else {
                    window.open('http://localhost:7860', '_blank');
                  }
                }}
              >
                Open in Browser <span aria-hidden="true">→</span>
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-3">Status</h3>
              <p className="text-sm text-slate-600 mb-4">Backend process managed by Tauri.</p>
              <button className="inline-flex items-center gap-2 rounded-md border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 transition">
                Refresh Status
              </button>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-slate-200 bg-white mt-auto py-4">
        <div className="max-w-6xl mx-auto px-6 text-xs text-slate-400">
          PrimeAgent Desktop · Tauri v2 · Built by KhulnaSoft, Ltd
        </div>
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
