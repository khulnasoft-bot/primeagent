# PrimeAgent Desktop

Tauri v2 wrapper for the [PrimeAgent](https://github.com/khulnasoft/primeagent) AI agent platform.

PrimeAgent Desktop launches the PrimeAgent backend on `localhost:7860` and provides a native desktop window to access the visual agent builder and workflow designer.

## Architecture

```
┌─────────────────────────────────────┐
│   PrimeAgent Desktop (Tauri v2)     │
│  ┌─────────────┐  ┌──────────────┐  │
│  │  WebView    │  │  System Tray │  │
│  │  (React)    │  │  (Rust)      │  │
│  └─────────────┘  └──────────────┘  │
│           │            │            │
│           ▼            ▼            │
│    localhost:7860   Backend Process │
│    (PrimeAgent API)   (Python/uv)   │
└─────────────────────────────────────┘
```

## Project Structure

```
primeagent-desktop/
├── Cargo.toml                  # Rust workspace root
├── package.json                # Frontend (Node/Vite)
├── index.html                  # Vite entry HTML
├── src/
│   ├── main.tsx                # React application entry
│   └── index.css               # Base styles
├── src-tauri/
│   ├── Cargo.toml              # Tauri core crate dependencies
│   ├── tauri.conf.json         # Tauri app configuration
│   └── src/
│       └── main.rs             # Rust backend launcher + window lifecycle
├── README.md
└── .gitignore
```

## Development

### Prerequisites

- [Rust](https://rustup.rs/) (1.82+)
- [Node.js](https://nodejs.org/) (20.19+)
- Python 3.10+ with `uv` (PrimeAgent's package manager)
- [Tauri CLI](https://tauri.app/v1/guides/getting-started/prerequisites#installing-the-cli) (`cargo install tauri-cli`)

### Install dependencies

```bash
# Frontend (Node)
npm install

# Rust (handled by cargo on build)
```

### Run in dev mode

```bash
npm run tauri dev
```

This starts the Vite dev server and the Tauri window. The Rust code attempts to start the PrimeAgent Python backend on `localhost:7860`.

### Build for production

```bash
npm run tauri build
```

Produces platform-specific installers (`.msi`, `.dmg`, `.deb`, `.rpm`, AppImage) under `src-tauri/target/release/bundle/`.

## Backend Discovery

On launch, `src-tauri/src/main.rs` locates the PrimeAgent Python backend by:

1. Checking `PRIMEAGENT_BACKEND_DIR` environment variable
2. Searching relative to the Tauri executable for `src/backend/base/primeagent/__main__.py`
3. Falling back to `uv`/`python3`/`python` on `PATH`

The backend is started with:

```bash
uv run primeagent run --host 127.0.0.1 --port 7860
```

Backend `stdout`/`stderr` is forwarded to the frontend via the `primeagent-backend-log` Tauri event.

## Commands

| Command | Description |
|---------|-------------|
| `start_backend` | Start the PrimeAgent Python backend subprocess |
| `stop_backend`  | Stop the running backend |
| `backend_status`| Returns whether the backend is running |

## License

MIT — see [LICENSE](../LICENSE)
