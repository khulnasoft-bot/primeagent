export interface Env {
  VITE_BACKEND_URL: string;
}
